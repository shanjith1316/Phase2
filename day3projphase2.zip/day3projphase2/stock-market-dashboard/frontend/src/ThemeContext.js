import React, { createContext, useContext, useState, useEffect } from "react";

// Create Theme Context
const ThemeContext = createContext();

// Theme Provider Component
export const ThemeProvider = ({ children }) => {
   const [darkMode, setDarkMode] = useState(() => {
      return localStorage.getItem("darkMode") === "true"; // Get saved theme from localStorage
   });

   useEffect(() => {
      localStorage.setItem("darkMode", darkMode); // Save theme preference
   }, [darkMode]);

   const toggleTheme = () => {
      setDarkMode((prevMode) => !prevMode);
   };

   return (
      <ThemeContext.Provider value={{ darkMode, toggleTheme }}>
         <div className={darkMode ? "dark-mode" : "light-mode"}>{children}</div>
      </ThemeContext.Provider>
   );
};

// Custom Hook to Use Theme
export const useTheme = () => useContext(ThemeContext);

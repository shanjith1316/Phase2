import React, { useState, useEffect } from "react";
import axios from "axios";
import io from "socket.io-client";
import "bootstrap/dist/css/bootstrap.min.css";
import { useTheme } from "./ThemeContext"; // Import Theme Context
import { Line } from "react-chartjs-2"; // Import Chart.js components
import { Chart as ChartJS, CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend } from "chart.js";

// Register chart elements
ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend);

const socket = io("http://localhost:5000");

const StockDashboard = () => {
   const { darkMode, toggleTheme } = useTheme(); // Get theme state and function
   const [symbol, setSymbol] = useState("TATA");
   const [stockData, setStockData] = useState(null);
   const [history, setHistory] = useState([]);
   const [chartData, setChartData] = useState({ labels: [], datasets: [] });

   useEffect(() => {
      fetchStockData(symbol);
   }, []);

   const fetchStockData = async (symbol) => {
      try {
         setStockData(null);
         const response = await axios.get(`http://localhost:5000/stock/${symbol}`);
         setStockData(response.data);
         setHistory((prev) => [...prev, symbol]);

         // Simulating past stock prices for the chart
         const prices = Array.from({ length: 10 }, () => (Math.random() * 1000).toFixed(2));
         setChartData({
            labels: Array.from({ length: 10 }, (_, i) => `Day ${i + 1}`),
            datasets: [
               {
                  label: `${symbol} Price`,
                  data: prices,
                  borderColor: darkMode ? "white" : "blue",
                  backgroundColor: darkMode ? "rgba(255, 255, 255, 0.1)" : "rgba(0, 0, 255, 0.2)",
                  tension: 0.3,
               },
            ],
         });

      } catch (error) {
         console.error("Error fetching stock data:", error);
      }
   };

   useEffect(() => {
      socket.emit("trackStock", symbol);
      socket.on("stockUpdate", (data) => {
         if (data.symbol === symbol) {
            setStockData(data);
         }
      });

      return () => socket.off("stockUpdate");
   }, [symbol]);

   return (
      <div className="container text-center mt-5">
         <h1 className="mb-3">📈 Stock Market Dashboard</h1>

         {/* 🌙☀️ Theme Toggle Button */}
         <button className="btn btn-secondary mb-3" onClick={toggleTheme}>
            {darkMode ? "☀️ Light Mode" : "🌙 Dark Mode"}
         </button>

         <input
            type="text"
            value={symbol}
            onChange={(e) => setSymbol(e.target.value)}
            className="form-control w-50 mx-auto"
         />
         <button className="btn btn-primary mt-2" onClick={() => fetchStockData(symbol)}>
            Fetch Stock Data
         </button>

         {stockData && (
            <div className="mt-4 p-3 border rounded bg-light">
               <h2>{stockData.symbol} Stock Price</h2>
               <h3>Current Price: 💰 ${stockData.price}</h3>
            </div>
         )}

         {/* Stock Price Chart */}
         <div className="mt-4">
            <h4>{symbol} Price Trends</h4>
            <div style={{ background: darkMode ? "#333" : "#fff", padding: "10px", borderRadius: "10px" }}>
               <Line data={chartData} />
            </div>
         </div>

         <h4 className="mt-4">Previous Searches</h4>
         <ul className="list-group w-50 mx-auto">
            {history.map((sym, index) => (
               <li key={index} className="list-group-item">
                  {sym}
               </li>
            ))}
         </ul>
      </div>
   );
};

export default StockDashboard;

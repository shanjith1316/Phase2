const express = require("express");
const cors = require("cors");
const http = require("http");
const { Server } = require("socket.io");
const axios = require("axios");

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
   cors: {
      origin: "http://localhost:3000", // Allow frontend to connect
      methods: ["GET", "POST"],
   },
});

// Enable CORS and JSON parsing
app.use(cors());
app.use(express.json());

const stockPrices = {}; // Store stock prices

// 🔹 API to Fetch Stock Data (GET /stock/:symbol)
app.get("/stock/:symbol", async (req, res) => {
   const { symbol } = req.params;
   try {
      // Simulating an API request (Replace this with a real API)
      const stockPrice = (Math.random() * 1000).toFixed(2); // Random price
      const stockData = { symbol, price: stockPrice };

      stockPrices[symbol] = stockData; // Store price
      res.json(stockData);
   } catch (error) {
      res.status(500).json({ error: "Error fetching stock data" });
   }
});

// 🔹 WebSocket for Real-Time Stock Updates
io.on("connection", (socket) => {
   console.log("Client connected");

   socket.on("trackStock", (symbol) => {
      console.log(`Tracking stock: ${symbol}`);

      // Send price updates every 3 seconds (simulating real-time data)
      const interval = setInterval(() => {
         const newPrice = (Math.random() * 1000).toFixed(2); // Random price
         stockPrices[symbol] = { symbol, price: newPrice };

         socket.emit("stockUpdate", stockPrices[symbol]); // Send updated price
      }, 3000);

      // Cleanup interval on disconnect
      socket.on("disconnect", () => {
         clearInterval(interval);
         console.log("Client disconnected");
      });
   });
});

// Start server on port 5000
server.listen(5000, () => console.log("Server running on http://localhost:5000"));

import React, { useState } from "react";
import axios from "axios";

function UserForm({ onUserAdded }) {
  const [name, setName] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    axios.post("http://localhost:5000/users", { name }).then((response) => {
      onUserAdded(response.data.user);

      setName("");
    });
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        type="text"
        value={name}
        onChange={(e) => setName(e.target.value)}
        placeholder="Enter user name"
        required
      />
      <button type="submit">Add User</button>
    </form>
  );
}

export default UserForm;

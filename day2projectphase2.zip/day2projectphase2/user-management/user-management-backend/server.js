const express = require("express");
const cors = require("cors");

const app = express();

// ✅ Enable CORS before defining any routes
app.use(cors({
   origin: "http://localhost:3000", // Allow frontend to access backend
   methods: ["GET", "POST"],
   allowedHeaders: ["Content-Type"]
}));

// ✅ Middleware to parse JSON data
app.use(express.json());

// ✅ Example route to fetch users
app.get("/users", (req, res) => {
   res.json([{ id: 1, name: "John Doe" }, { id: 2, name: "Jane Doe" }]);
});

// ✅ Example route to add a user
app.post("/users", (req, res) => {
   const newUser = req.body;
   console.log("New User Data Received:", newUser); // Log the received data

   console.log("New User:", newUser);
   res.status(201).json({ message: "User added successfully", user: newUser });
});

// ✅ Start the backend server
app.listen(5000, '0.0.0.0', () => {
   console.log("Backend server running on port 5000");
});
